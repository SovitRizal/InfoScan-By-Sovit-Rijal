import whois
from faker import Faker

print("_________ _        _______  _______       _     _______  _______  _       ")
print("\__   __/( (    /|(  ____ \(  ___  )   __|_|___(  ____ \(  ___  )( (    /|")
print("   ) (   |  \  ( || (    \/| (   ) |  (  _____/| (    \/| (   ) ||  \  ( |")
print("   | |   |   \ | || (__    | |   | |  | (|_|__ | |      | (___) ||   \ | |")
print("   | |   | (\ \) ||  __)   | |   | |  (_____  )| |      |  ___  || (\ \) |")
print("   | |   | | \   || (      | |   | |  /\_|_|) || |      | (   ) || | \   |")
print("___) (___| )  \  || )      | (___) |  \_______)| (____/\| )   ( || )  \  |")
print("\_______/|/    )_)|/       (_______)     |_|   (_______/|/     \||/    )_)")
                                                                          




print("What do you like to use, Fake detail or domain scan? Q to quit")
choice = int (input(":"))

if choice == 1:

    def domain_whois(domain):
        try:
            w = whois.whois(domain)
            return {
                "domain": domain,
                "registrar": w.registrar,
                "creation_date": w.creation_date,
                "expiration_date": w.expiration_date,
                "nameservers": w.name_servers,
            }
        except Exception as e:
            return {"error": str(e)}

    if __name__ == "__main__":
        domain = input("Enter domain: ")
        result = domain_whois(domain)
        for key, value in result.items():
            print(f"{key}: {value}")
        print("What do you like to use, Fake detail or domain scan? Q to quit")
        choice = input(":")

elif choice == 2:
    fake = Faker()
    print(f"Fake name is - {fake.name()}")
    print(f"Fake email is - {fake.email()}")
    print(f"Fake number is - {fake.phone_number()}")

else:
    print("ERROR ... EZOX")
