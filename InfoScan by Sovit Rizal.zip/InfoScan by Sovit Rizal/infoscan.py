import whois
from faker import Faker



# ASCII Art
ascii_art = """
  __   __/( (    /|(  ____ \(  ___  )   __|_|___(  ____ \(  ___  )( (    /|
   ) (   |  \  ( || (    \/| (   ) |  (  _____/| (    \/| (   ) ||  \  ( |
   | |   |   \ | || (__    | |   | |  | (|_|__ | |      | (___) ||   \ | |
   | |   | (\ \) ||  __)   | |   | |  (_____  )| |      |  ___  || (\ \) |
   | |   | | \   || (      | |   | |  /\_|_|) || |      | (   ) || | \   |
___) (___| )  \  || )      | (___) |  \_______)| (____/\| )   ( || )  \  |
\_______/|/    )_)|/       (_______)     |_|   (_______/|/     \||/    )_)
"""



running = True


while running:


    print(ascii_art)


    print("What do you like to use")
    print("1 for Domain Scan ")
    print("2 for Fake Detail")
    choice = input(":").strip()

    if choice == "1":
        def domain_whois(domain):
            try:
                w = whois.whois(domain)
                return {
                    "domain": domain,
                    "registrar": w.registrar,
                    "creation_date": w.creation_date,
                    "expiration_date": w.expiration_date,
                    "nameservers": w.name_servers,
                }
            except Exception as e:
                return {"error": str(e)}

        domain = input("Enter domain: ").strip()
        result = domain_whois(domain)
        for key, value in result.items():
            print(f"{key}: {value}")

    elif choice == "2":
        fake = Faker()
        print(f"Fake name is - {fake.name()}")
        print(f"Fake email is - {fake.email()}")
        print(f"Fake number is - {fake.phone_number()}")

    elif choice.lower() == "q":
        print("Exiting...")
    else:
        print("ERROR ... Invalid Choice")
        running = False