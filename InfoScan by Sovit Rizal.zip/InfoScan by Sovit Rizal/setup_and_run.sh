#!/bin/bash

# Ensure script is run with sudo if needed
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root or use sudo for permissions"
  exit
fi

# Step 1: Update system packages and ensure Python is installed
echo "Updating system and ensuring Python 3 is installed..."
sudo apt update && sudo apt install -y python3 python3-venv

# Step 2: Create a virtual environment
VENV_DIR="venv_infoscan"
if [ ! -d "$VENV_DIR" ]; then
  echo "Creating a virtual environment..."
  python3 -m venv "$VENV_DIR"
fi

# Step 3: Activate the virtual environment
echo "Activating the virtual environment..."
source "$VENV_DIR/bin/activate"

# Step 4: Install required Python packages
echo "Installing required Python packages..."
pip install --upgrade pip
pip install whois faker

# Step 5: Run the Python script
echo "Running infoscan.py..."
python3 infoscan.py

# Step 6: Deactivate the virtual environment after execution
deactivate
echo "Execution complete. Virtual environment deactivated."
